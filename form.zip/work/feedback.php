<?php
require 'vendor/autoload.php';


use Dotenv\Dotenv;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

/**
 * Обработка данных из формы обратной связи и отправка на почту с использованием mail() в PHP.
 * @param string $email Email адрес отправителя.
 * @param string $message Сообщение отправителя.
 * @return bool Успешно ли отправлено письмо.
 */

function sendFeedbackEmail($email, $message)
{
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();
        $mail->Host = $_ENV['MAIL_HOST']; // Вставьте  адрес вашего SMTP-сервера
        $mail->Username = $_ENV['MAIL_USERNAME']; // Вставьте на имя пользователя SMTP
        $mail->Password = $_ENV['MAIL_PASSWORD'];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = $_ENV['MAIL_PORT'];

        $mail->setFrom($email);
        $mail->addAddress($_ENV['MAIL_USERNAME']);
        $mail->isHTML(true);
        $mail->Subject = 'Обратная связь';
        $mail->Body = "<div>Вас просили написать на почту $email</div><div>Текст сообщения</div><div>$message</div>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $message = $_POST["message"];

    if (empty($email) || empty($message)) {
        echo "Заполните все поля.";
    } else {
        if (preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $email)) {
            $sent = sendFeedbackEmail($email, $message);
            if ($sent) {
                echo "Спасибо! Мы получили ваше сообщеие и скоро вам ответим";
            } else {
                http_response_code(500);
                echo "Произошла ошибка при отправке сообщения.";
            }
        } else {
            http_response_code(400);
            echo "Неправильный формат email.";
        }
    }
} else {
    http_response_code(301);
    header("Location: feedback_form.html");
    exit;
}
